    <nav
        class="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 py-2">
        <div class="flex justify-around max-w-2xl mx-auto">
            <a href="{{ route('guru.dashboard.index') }}"
                class="flex flex-col items-center text-gray-400 {{ request()->is('guru') ? 'text-bangala' : 'hover:text-bangala' }}">
                <i class="fas fa-home"></i>
                <span class="text-xs mt-1">Beranda</span>
            </a>
            <a href="{{ route('guru.penilaian.index') }}"
                class="flex flex-col items-center text-gray-400 {{ request()->is('guru/penilaian*') ? 'text-bangala' : 'hover:text-bangala' }}">
                <i class="fas fa-clipboard-check text-sm sm:text-base"></i>
                <span class="text-xs mt-1">Penilaian</span>
            </a>
            @if (auth()->user()->jabatans->contains(fn($j) => $j->jabatan->jabatan == 'kepala_sekolah') ||
                    auth()->user()->jabatans->contains(fn($j) => $j->jabatan->jabatan == 'wakasek'))
                <a href="{{ route('guru.rapor.kepsek') }}"
                    class="flex flex-col items-center text-gray-400 {{ request()->is('guru/rapor*') ? 'text-bangala' : 'hover:text-bangala' }}">
                    <i class="fas fa-file-alt text-sm sm:text-base"></i>
                    <span class="text-xs mt-1">Rapor</span>
                </a>
            @else
                <a href="{{ route('guru.statistik') }}"
                    class="flex flex-col items-center text-gray-400 {{ request()->is('guru/statistik*') ? 'text-bangala' : 'hover:text-bangala' }}">
                    <i class="fas fa-chart-line text-sm sm:text-base"></i>
                    <span class="text-xs mt-1">Statistik</span>
                </a>
            @endif
            <a href="{{ route('guru.profile') }}"
                class="flex flex-col items-center text-gray-400 {{ request()->is('guru/profil*') ? 'text-bangala' : 'hover:text-bangala' }}">
                <i class="fas fa-user"></i>
                <span class="text-xs mt-1">Profil</span>
            </a>
            <button onclick="confirmLogout('{{ route('logout') }}','{{ route('login') }}')"
                class="flex flex-col items-center text-gray-400 hover:text-bangala">
                <i class="fas fa-sign-out-alt text-base"></i>
                <span class="text-xs mt-1">Logout</span>
            </button>

        </div>
    </nav>
